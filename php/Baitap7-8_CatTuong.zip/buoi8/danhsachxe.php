<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cartague</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Gugi&display=swap" rel="stylesheet"> 
    <style>
        *{
            margin: 0 auto;
        }
        h1{
            width: 100%;
            border-bottom: 1px solid orange;
            padding-bottom: 20px;
            padding-top: 20px;
            box-shadow: 0 2px 5px #FA6400;
            font-family: 'Gugi',cursive;
            font-weight: 700;
            font-size: 5rem;
        }
        main{
            display: flex;
            flex-wrap: wrap;
            flex-direction: row;
            justify-content: center;
            align-items: flex-start;
        }
        .cars {
            display: block;
            float: left;
            width: 300px;
            height: 375px;
            margin: 20px;
            box-shadow: 2px 2px 5px #000;
            border: 1px solid grey;
            border-radius: 10px;
        }
        .sum::after{
            content: "";
            clear: both;
            display: table;
        }
        .car>img{
            margin-right: 10px;
        }
        a{
            width: 100px;
            display: block;
            border: 1px solid red;
            background-color: #FA6400;
            font-family: 'Gugi',cursive;
            color: #FFFFFF;
            text-decoration: none;
            text-align: center;
            height: 30px;
            border-radius: 20px;
            margin: 0 auto;
            padding-top: 15px;
            font-weight: 700;
            font-size: 1.1rem;
        }
        a:hover{
            border-color: #FFFFFF;
            background-color: #FB8332;
            box-shadow: 2px 2px 2px #888888;
        }
        .sum{
            display: flex;
            flex-direction: column;
            justify-content: space-around;
            padding-left: 20px;
            height: 170px;
            align-items: center;
        }
        .info{
            display: block;
            float: left;
            margin: 0 auto;
        }
        .info>img{
            width: 300px;
        }
        .detail{
            width: 40%;
            margin: 20px;
        }
        h2{
            margin: 0;
        }
    </style>
</head>
<body>
    <h1 align="center">Sport & Muscle Car</h1>
    <main>
        <?php require("dsx.php");
        if(isset($_GET["page"])){
            $pa = $_GET["page"];
            switch($pa){
                case "detail": 
                    require("chitiet.php");
                    break;
                case "danhsach":
                    require("lietke.php");
                break;
            }
        }else{
            require("lietke.php");
        }
        ?>
    </main>
</body>
</html>