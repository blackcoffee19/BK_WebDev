<?php require('dsx.php');
    foreach($ds as $key => $value){
        echo "<div class='cars'>";
        echo "<img src='".$value[0]."' width='300px' height='200px'>";
        echo "<div class='sum'><h3>{$value[1]}</h3>";
        echo "<p style='color:red;font-weight:700;'>{$value[2]}</p>";
        echo "<a href='?page=detail&lo=".$key."'>Chi tiết</a></div>";
        echo "</div>";
    }
?>