<?php
    if(isset($_GET["lo"])){
        $ms = $_GET["lo"];
        foreach($ds as $key => $value){
            if($key == $ms){
                echo "<img width='40%' style='margin:20px' src='".$value[0]."'>";
                echo "<div class='detail'><h2>".$value[1]."</h2><br><p style='color:red;font-weight:700;'>".$value[2]."</p><br>";
                echo "<h3>Overview</h3><p style='color:#000;'>".$value[3]."</p></div>";
            }
        }
    }
?>